# StarCraft
Task for work with mentor from Strypes